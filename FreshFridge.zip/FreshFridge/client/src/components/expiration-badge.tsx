import { Badge } from "@/components/ui/badge";
import { differenceInDays, parseISO } from "date-fns";

interface ExpirationBadgeProps {
  expirationDate: string;
  className?: string;
}

export function ExpirationBadge({ expirationDate, className }: ExpirationBadgeProps) {
  const today = new Date();
  const expDate = parseISO(expirationDate);
  const daysUntilExpiration = differenceInDays(expDate, today);

  let variant: "default" | "destructive" | "secondary" = "default";
  let text = "";

  if (daysUntilExpiration < 0) {
    variant = "destructive";
    text = "Expired";
  } else if (daysUntilExpiration === 0) {
    variant = "destructive";
    text = "Expires today";
  } else if (daysUntilExpiration <= 3) {
    variant = "secondary";
    text = `${daysUntilExpiration}d left`;
  } else {
    variant = "default";
    text = `${daysUntilExpiration}d left`;
  }

  return (
    <Badge variant={variant} className={className} data-testid="badge-expiration">
      {text}
    </Badge>
  );
}
