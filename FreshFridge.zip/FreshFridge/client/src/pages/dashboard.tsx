import { useQuery } from "@tanstack/react-query";
import type { FoodItem, MealPlan } from "@shared/schema";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, ChefHat, ShoppingCart, AlertTriangle, Calendar } from "lucide-react";
import { ExpirationBadge } from "@/components/expiration-badge";
import { differenceInDays, parseISO, format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { useCurrentUser } from "@/components/user-context";

export default function Dashboard() {
  const { currentUserId } = useCurrentUser();

  const { data: allFoodItems = [], isLoading: loadingFood } = useQuery<FoodItem[]>({
    queryKey: ["/api/food-items"],
  });

  const foodItems = allFoodItems.filter((item) => item.userId === currentUserId);

  const { data: mealPlans = [], isLoading: loadingMeals } = useQuery<MealPlan[]>({
    queryKey: ["/api/meal-plans"],
  });

  const expiringItems = foodItems
    .filter((item) => {
      const days = differenceInDays(parseISO(item.expirationDate), new Date());
      return days >= 0 && days <= 7;
    })
    .sort((a, b) => parseISO(a.expirationDate).getTime() - parseISO(b.expirationDate).getTime());

  const expiredItems = foodItems.filter((item) => {
    const days = differenceInDays(parseISO(item.expirationDate), new Date());
    return days < 0;
  });

  const upcomingMeals = mealPlans
    .filter((meal) => parseISO(meal.date) >= new Date())
    .sort((a, b) => parseISO(a.date).getTime() - parseISO(b.date).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-heading text-3xl font-semibold">Dashboard</h1>
        <p className="text-muted-foreground">Your food inventory overview</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Items</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loadingFood ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <div className="text-2xl font-bold">{foodItems.length}</div>
            )}
            <p className="text-xs text-muted-foreground">In your inventory</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expiring Soon</CardTitle>
            <AlertTriangle className="h-4 w-4 text-chart-2" />
          </CardHeader>
          <CardContent>
            {loadingFood ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <div className="text-2xl font-bold">{expiringItems.length}</div>
            )}
            <p className="text-xs text-muted-foreground">Within 7 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expired</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            {loadingFood ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <div className="text-2xl font-bold">{expiredItems.length}</div>
            )}
            <p className="text-xs text-muted-foreground">Need attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Meals</CardTitle>
            <ChefHat className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {loadingMeals ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <div className="text-2xl font-bold">{upcomingMeals.length}</div>
            )}
            <p className="text-xs text-muted-foreground">Planned this week</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-chart-2" />
              Expiration Alert
            </CardTitle>
            <CardDescription>Items expiring in the next 7 days</CardDescription>
          </CardHeader>
          <CardContent>
            {loadingFood ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-center justify-between">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-6 w-16" />
                  </div>
                ))}
              </div>
            ) : expiringItems.length === 0 ? (
              <p className="text-sm text-muted-foreground">No items expiring soon 🎉</p>
            ) : (
              <div className="space-y-3">
                {expiringItems.slice(0, 5).map((item) => (
                  <div key={item.id} className="flex items-center justify-between gap-4" data-testid={`expiring-item-${item.id}`}>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {item.quantity} {item.unit} • {item.storageLocation}
                      </p>
                    </div>
                    <ExpirationBadge expirationDate={item.expirationDate} />
                  </div>
                ))}
                {expiringItems.length > 5 && (
                  <Button variant="ghost" size="sm" asChild className="w-full" data-testid="button-view-all-expiring">
                    <Link href="/inventory">View all {expiringItems.length} items</Link>
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              Upcoming Meals
            </CardTitle>
            <CardDescription>Your meal plan for the week</CardDescription>
          </CardHeader>
          <CardContent>
            {loadingMeals ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="space-y-1">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-32" />
                  </div>
                ))}
              </div>
            ) : upcomingMeals.length === 0 ? (
              <div className="text-center py-4">
                <p className="text-sm text-muted-foreground mb-3">No meals planned yet</p>
                <Button asChild size="sm" data-testid="button-plan-meals">
                  <Link href="/meal-plan">Plan Your Meals</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {upcomingMeals.map((meal) => (
                  <div key={meal.id} className="space-y-1" data-testid={`upcoming-meal-${meal.id}`}>
                    <p className="text-xs text-muted-foreground">
                      {format(parseISO(meal.date), "EEE, MMM d")} • {meal.mealType}
                    </p>
                    <p className="text-sm font-medium">{meal.recipeName}</p>
                  </div>
                ))}
                <Button variant="ghost" size="sm" asChild className="w-full" data-testid="button-view-meal-plan">
                  <Link href="/meal-plan">View Full Calendar</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {expiredItems.length > 0 && (
        <Card className="border-destructive">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5" />
              Expired Items
            </CardTitle>
            <CardDescription>These items need your attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {expiredItems.slice(0, 3).map((item) => (
                <div key={item.id} className="flex items-center justify-between gap-4 p-2 rounded-md bg-destructive/10" data-testid={`expired-item-${item.id}`}>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{item.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {item.quantity} {item.unit} • Expired {format(parseISO(item.expirationDate), "MMM d, yyyy")}
                    </p>
                  </div>
                  <ExpirationBadge expirationDate={item.expirationDate} />
                </div>
              ))}
              {expiredItems.length > 3 && (
                <Button variant="destructive" size="sm" asChild className="w-full" data-testid="button-view-expired">
                  <Link href="/inventory">View all {expiredItems.length} expired items</Link>
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
