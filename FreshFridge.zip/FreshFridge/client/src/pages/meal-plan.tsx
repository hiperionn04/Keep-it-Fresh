import { useQuery, useMutation } from "@tanstack/react-query";
import type { ShoppingListItem, InsertShoppingListItem } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, ShoppingCart } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertShoppingListItemSchema } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";

const categories = ["Produce", "Dairy", "Meat & Seafood", "Pantry", "Frozen", "Bakery", "Other"];

export default function ShoppingList() {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const { toast } = useToast();

  const { data: items = [], isLoading } = useQuery<ShoppingListItem[]>({
    queryKey: ["/api/shopping-list"],
  });

  const addMutation = useMutation({
    mutationFn: (data: InsertShoppingListItem) => apiRequest("POST", "/api/shopping-list", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shopping-list"] });
      setIsAddOpen(false);
      toast({ description: "Item added to shopping list" });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: ({ id, checked }: { id: string; checked: boolean }) =>
      apiRequest("PATCH", `/api/shopping-list/${id}`, { checked }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shopping-list"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/shopping-list/${id}`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shopping-list"] });
      toast({ description: "Item removed from list" });
    },
  });

  const clearCheckedMutation = useMutation({
    mutationFn: () => apiRequest("DELETE", "/api/shopping-list/checked", {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shopping-list"] });
      toast({ description: "Checked items cleared" });
    },
  });

  const itemsByCategory = categories.map((category) => ({
    category,
    items: items.filter((item) => item.category === category),
  })).filter((group) => group.items.length > 0);

  const checkedCount = items.filter((item) => item.checked).length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="font-heading text-3xl font-semibold">Shopping List</h1>
          <p className="text-muted-foreground">
            {items.length > 0 && `${checkedCount} of ${items.length} items checked`}
          </p>
        </div>
        <div className="flex gap-2">
          {checkedCount > 0 && (
            <Button
              variant="outline"
              onClick={() => clearCheckedMutation.mutate()}
              disabled={clearCheckedMutation.isPending}
              data-testid="button-clear-checked"
            >
              Clear Checked
            </Button>
          )}
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-shopping-item">
                <Plus className="h-4 w-4" />
                Add Item
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add Shopping Item</DialogTitle>
                <DialogDescription>Add a new item to your shopping list</DialogDescription>
              </DialogHeader>
              <ShoppingItemForm
                onSubmit={(data) => addMutation.mutate(data)}
                isPending={addMutation.isPending}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-5 w-24 mb-3" />
                <div className="space-y-2">
                  {[1, 2].map((j) => (
                    <Skeleton key={j} className="h-10 w-full" />
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : items.length === 0 ? (
        <Card className="py-16">
          <CardContent className="flex flex-col items-center justify-center text-center">
            <ShoppingCart className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="font-heading text-xl font-semibold mb-2">Your shopping list is empty</h3>
            <p className="text-muted-foreground mb-4 max-w-sm">
              Add items you need to buy on your next grocery run
            </p>
            <Button onClick={() => setIsAddOpen(true)} data-testid="button-add-first-shopping-item">
              <Plus className="h-4 w-4" />
              Add First Item
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {itemsByCategory.map((group) => (
            <Card key={group.category}>
              <CardContent className="p-4">
                <h3 className="font-medium text-sm text-muted-foreground mb-3">{group.category}</h3>
                <div className="space-y-2">
                  {group.items.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center gap-3 p-2 rounded-md hover-elevate"
                      data-testid={`shopping-item-${item.id}`}
                    >
                      <Checkbox
                        checked={item.checked}
                        onCheckedChange={(checked) =>
                          toggleMutation.mutate({ id: item.id, checked: !!checked })
                        }
                        data-testid={`checkbox-${item.id}`}
                      />
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm font-medium ${item.checked ? "line-through text-muted-foreground" : ""}`}>
                          {item.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {item.quantity} {item.unit}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => deleteMutation.mutate(item.id)}
                        data-testid={`button-delete-shopping-item-${item.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function ShoppingItemForm({
  onSubmit,
  isPending,
}: {
  onSubmit: (data: InsertShoppingListItem) => void;
  isPending: boolean;
}) {
  const form = useForm<InsertShoppingListItem>({
    resolver: zodResolver(insertShoppingListItemSchema),
    defaultValues: {
      name: "",
      quantity: "",
      unit: "",
      category: "Other",
      checked: false,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Item Name</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Mozzarella Cheese" {...field} data-testid="input-shopping-item-name" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="quantity"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Quantity</FormLabel>
                <FormControl>
                  <Input placeholder="e.g., 2" {...field} data-testid="input-shopping-quantity" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="unit"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Unit</FormLabel>
                <FormControl>
                  <Input placeholder="e.g., packs, kg" {...field} data-testid="input-shopping-unit" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="category"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Category</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger data-testid="select-shopping-category">
                    <SelectValue />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex gap-2 justify-end">
          <Button type="submit" disabled={isPending} data-testid="button-submit-shopping-item">
            {isPending ? "Adding..." : "Add to List"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
