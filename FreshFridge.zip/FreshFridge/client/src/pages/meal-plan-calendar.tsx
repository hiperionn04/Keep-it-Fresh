import { useQuery, useMutation } from "@tanstack/react-query";
import type { MealPlan, Recipe, InsertMealPlan } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Calendar as CalendarIcon, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertMealPlanSchema } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { format, parseISO, addDays, startOfWeek, endOfWeek } from "date-fns";

const mealTypes = ["Breakfast", "Lunch", "Dinner", "Snack"];

export default function MealPlanCalendar() {
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [currentWeekStart, setCurrentWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const { toast } = useToast();

  const { data: mealPlans = [], isLoading } = useQuery<MealPlan[]>({
    queryKey: ["/api/meal-plans"],
  });

  const { data: recipes = [] } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
  });

  const addMutation = useMutation({
    mutationFn: (data: InsertMealPlan) => apiRequest("POST", "/api/meal-plans", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
      setSelectedDate(null);
      toast({ description: "Meal added to plan" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/meal-plans/${id}`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
      toast({ description: "Meal removed from plan" });
    },
  });

  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(currentWeekStart, i));

  const getMealsForDate = (date: Date) => {
    const dateStr = format(date, "yyyy-MM-dd");
    return mealPlans.filter((meal) => meal.date === dateStr);
  };

  const goToPreviousWeek = () => {
    setCurrentWeekStart(addDays(currentWeekStart, -7));
  };

  const goToNextWeek = () => {
    setCurrentWeekStart(addDays(currentWeekStart, 7));
  };

  const goToToday = () => {
    setCurrentWeekStart(startOfWeek(new Date(), { weekStartsOn: 1 }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="font-heading text-3xl font-semibold">Meal Plan</h1>
          <p className="text-muted-foreground">Plan your meals for the week</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={goToPreviousWeek} data-testid="button-previous-week">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" onClick={goToToday} data-testid="button-today">
            Today
          </Button>
          <Button variant="outline" size="icon" onClick={goToNextWeek} data-testid="button-next-week">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="text-center">
        <p className="text-sm text-muted-foreground">
          {format(currentWeekStart, "MMM d")} - {format(endOfWeek(currentWeekStart, { weekStartsOn: 1 }), "MMM d, yyyy")}
        </p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
          {weekDays.map((_, i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-5 w-16 mb-3" />
                <div className="space-y-2">
                  {[1, 2].map((j) => (
                    <Skeleton key={j} className="h-16 w-full" />
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
          {weekDays.map((day) => {
            const dayMeals = getMealsForDate(day);
            const isToday = format(day, "yyyy-MM-dd") === format(new Date(), "yyyy-MM-dd");

            return (
              <Card key={day.toISOString()} className={isToday ? "border-primary" : ""}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <p className="text-xs text-muted-foreground">{format(day, "EEE")}</p>
                      <p className={`font-medium ${isToday ? "text-primary" : ""}`}>{format(day, "d")}</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => setSelectedDate(format(day, "yyyy-MM-dd"))}
                      data-testid={`button-add-meal-${format(day, "yyyy-MM-dd")}`}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="space-y-2">
                    {dayMeals.length === 0 ? (
                      <div className="text-center py-4">
                        <p className="text-xs text-muted-foreground">No meals planned</p>
                      </div>
                    ) : (
                      dayMeals.map((meal) => (
                        <div
                          key={meal.id}
                          className="p-2 rounded-md bg-accent/50 hover-elevate group"
                          data-testid={`meal-${meal.id}`}
                        >
                          <div className="flex items-start justify-between gap-1">
                            <div className="flex-1 min-w-0">
                              <p className="text-xs text-muted-foreground">{meal.mealType}</p>
                              <p className="text-sm font-medium truncate">{meal.recipeName}</p>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={() => deleteMutation.mutate(meal.id)}
                              data-testid={`button-delete-meal-${meal.id}`}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={!!selectedDate} onOpenChange={(open) => !open && setSelectedDate(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add Meal</DialogTitle>
            <DialogDescription>
              {selectedDate && `Plan a meal for ${format(parseISO(selectedDate), "EEEE, MMM d")}`}
            </DialogDescription>
          </DialogHeader>
          {selectedDate && (
            <MealPlanForm
              date={selectedDate}
              recipes={recipes}
              onSubmit={(data) => addMutation.mutate(data)}
              isPending={addMutation.isPending}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function MealPlanForm({
  date,
  recipes,
  onSubmit,
  isPending,
}: {
  date: string;
  recipes: Recipe[];
  onSubmit: (data: InsertMealPlan) => void;
  isPending: boolean;
}) {
  const form = useForm<InsertMealPlan>({
    resolver: zodResolver(insertMealPlanSchema),
    defaultValues: {
      date,
      mealType: "Lunch",
      recipeId: "",
      recipeName: "",
      servings: 4,
    },
  });

  const selectedRecipeId = form.watch("recipeId");
  const selectedRecipe = recipes.find((r) => r.id === selectedRecipeId);

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit((data) => {
          const recipe = recipes.find((r) => r.id === data.recipeId);
          if (recipe) {
            onSubmit({
              ...data,
              recipeName: recipe.name,
              servings: data.servings || recipe.servings,
            });
          }
        })}
        className="space-y-4"
      >
        <FormField
          control={form.control}
          name="mealType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Meal Type</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger data-testid="select-meal-type">
                    <SelectValue />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {mealTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="recipeId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Recipe</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger data-testid="select-recipe">
                    <SelectValue placeholder="Select a recipe" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {recipes.length === 0 ? (
                    <div className="p-2 text-sm text-muted-foreground">No recipes available</div>
                  ) : (
                    recipes.map((recipe) => (
                      <SelectItem key={recipe.id} value={recipe.id}>
                        {recipe.name}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="servings"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Servings</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  {...field}
                  onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                  placeholder={selectedRecipe?.servings.toString() || "4"}
                  data-testid="input-meal-servings"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex gap-2 justify-end">
          <Button type="submit" disabled={isPending || !selectedRecipeId} data-testid="button-submit-meal-plan">
            {isPending ? "Adding..." : "Add to Plan"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
