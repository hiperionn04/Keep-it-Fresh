import { useQuery, useMutation } from "@tanstack/react-query";
import type { Recipe, FoodItem, InsertRecipe, RecipeIngredient, SubRecipe } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Edit2, Trash2, ChefHat, Users, Clock, CheckCircle2, XCircle } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertRecipeSchema } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useCurrentUser } from "@/components/user-context";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Separator } from "@/components/ui/separator";

export default function Recipes() {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingRecipe, setEditingRecipe] = useState<Recipe | null>(null);
  const [deletingRecipe, setDeletingRecipe] = useState<Recipe | null>(null);
  const [showStockChecker, setShowStockChecker] = useState(false);
  const { toast } = useToast();
  const { currentUserId } = useCurrentUser();

  const { data: recipes = [], isLoading } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes"],
  });

  const { data: allFoodItems = [] } = useQuery<FoodItem[]>({
    queryKey: ["/api/food-items"],
  });

  const foodItems = allFoodItems.filter((item) => item.userId === currentUserId);

  const addMutation = useMutation({
    mutationFn: (data: InsertRecipe) => apiRequest("POST", "/api/recipes", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      setIsAddOpen(false);
      toast({ description: "Recipe created successfully" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: InsertRecipe }) =>
      apiRequest("PATCH", `/api/recipes/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      setEditingRecipe(null);
      toast({ description: "Recipe updated successfully" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/recipes/${id}`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      setDeletingRecipe(null);
      toast({ description: "Recipe deleted successfully" });
    },
  });

  const canMakeRecipe = (recipe: Recipe) => {
    const allIngredients = [...recipe.ingredients];
    if (recipe.subRecipes) {
      recipe.subRecipes.forEach((sub) => {
        allIngredients.push(...sub.ingredients);
      });
    }

    return allIngredients.every((ingredient) =>
      foodItems.some((item) => item.name.toLowerCase().includes(ingredient.name.toLowerCase()))
    );
  };

  const getMissingIngredients = (recipe: Recipe) => {
    const allIngredients = [...recipe.ingredients];
    if (recipe.subRecipes) {
      recipe.subRecipes.forEach((sub) => {
        allIngredients.push(...sub.ingredients);
      });
    }

    return allIngredients.filter(
      (ingredient) =>
        !foodItems.some((item) => item.name.toLowerCase().includes(ingredient.name.toLowerCase()))
    );
  };

  const recipesYouCanMake = recipes.filter(canMakeRecipe);
  const recipesWithMissingIngredients = recipes.filter((r) => !canMakeRecipe(r));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="font-heading text-3xl font-semibold">Recipes</h1>
          <p className="text-muted-foreground">Manage your recipe collection</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setShowStockChecker(!showStockChecker)}
            data-testid="button-toggle-stock-checker"
          >
            {showStockChecker ? "Hide" : "Show"} Stock Checker
          </Button>
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-recipe">
                <Plus className="h-4 w-4" />
                Create Recipe
              </Button>
            </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Recipe</DialogTitle>
              <DialogDescription>Add a new recipe with ingredients and optional sub-recipes</DialogDescription>
            </DialogHeader>
            <RecipeForm
              onSubmit={(data) => addMutation.mutate(data)}
              isPending={addMutation.isPending}
            />
          </DialogContent>
        </Dialog>
        </div>
      </div>

      {showStockChecker && (
        <Card className="border-primary">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-primary" />
              Stock Checker & Recipe Suggestions
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Compare recipes with your current inventory
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            {recipes.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                No recipes to check. Create a recipe first!
              </p>
            ) : foodItems.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                No food items in inventory. Add items to see what you can make!
              </p>
            ) : (
              <>
                <div>
                  <h3 className="font-medium text-sm text-primary mb-3">
                    ✓ Recipes You Can Make ({recipesYouCanMake.length})
                  </h3>
                  {recipesYouCanMake.length === 0 ? (
                    <p className="text-sm text-muted-foreground">
                      You don't have all ingredients for any recipe yet.
                    </p>
                  ) : (
                    <div className="grid gap-2">
                      {recipesYouCanMake.map((recipe) => (
                        <div
                          key={recipe.id}
                          className="p-3 rounded-md bg-primary/10 border border-primary/20"
                          data-testid={`can-make-${recipe.id}`}
                        >
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="h-4 w-4 text-primary" />
                            <span className="font-medium">{recipe.name}</span>
                            <Badge variant="default" className="ml-auto">Ready to cook</Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {recipesWithMissingIngredients.length > 0 && (
                  <div>
                    <h3 className="font-medium text-sm text-muted-foreground mb-3">
                      Missing Ingredients ({recipesWithMissingIngredients.length} recipes)
                    </h3>
                    <div className="space-y-3">
                      {recipesWithMissingIngredients.map((recipe) => {
                        const missing = getMissingIngredients(recipe);
                        return (
                          <div
                            key={recipe.id}
                            className="p-3 rounded-md bg-muted/50 border"
                            data-testid={`missing-ingredients-${recipe.id}`}
                          >
                            <div className="flex items-start gap-2 mb-2">
                              <XCircle className="h-4 w-4 text-muted-foreground mt-0.5" />
                              <div className="flex-1">
                                <p className="font-medium">{recipe.name}</p>
                                <p className="text-xs text-muted-foreground mt-1">
                                  Missing {missing.length} ingredient{missing.length !== 1 ? "s" : ""}:
                                </p>
                              </div>
                            </div>
                            <div className="ml-6 flex flex-wrap gap-1">
                              {missing.map((ingredient, idx) => (
                                <Badge key={idx} variant="secondary" className="text-xs">
                                  {ingredient.name} ({ingredient.quantity} {ingredient.unit})
                                </Badge>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent className="space-y-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-9 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : recipes.length === 0 ? (
        <Card className="py-16">
          <CardContent className="flex flex-col items-center justify-center text-center">
            <ChefHat className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="font-heading text-xl font-semibold mb-2">No recipes yet</h3>
            <p className="text-muted-foreground mb-4 max-w-sm">
              Create your first recipe to start meal planning
            </p>
            <Button onClick={() => setIsAddOpen(true)} data-testid="button-create-first-recipe">
              <Plus className="h-4 w-4" />
              Create Your First Recipe
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {recipes.map((recipe) => {
            const canMake = canMakeRecipe(recipe);
            return (
              <Card key={recipe.id} className="hover-elevate" data-testid={`card-recipe-${recipe.id}`}>
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-lg">{recipe.name}</CardTitle>
                    {canMake ? (
                      <Badge variant="default" className="gap-1">
                        <CheckCircle2 className="h-3 w-3" />
                        Can Make
                      </Badge>
                    ) : (
                      <Badge variant="secondary" className="gap-1">
                        <XCircle className="h-3 w-3" />
                        Missing Items
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      <span>{recipe.servings} servings</span>
                    </div>
                    {recipe.prepTime && (
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        <span>{recipe.prepTime}</span>
                      </div>
                    )}
                  </div>

                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-1">Ingredients</p>
                    <p className="text-sm">{recipe.ingredients.length} items</p>
                  </div>

                  {recipe.subRecipes && recipe.subRecipes.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1">Sub-recipes</p>
                      <div className="flex flex-wrap gap-1">
                        {recipe.subRecipes.map((sub) => (
                          <Badge key={sub.id} variant="outline" className="text-xs">
                            {sub.name}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => setEditingRecipe(recipe)}
                      data-testid={`button-edit-recipe-${recipe.id}`}
                    >
                      <Edit2 className="h-3 w-3" />
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setDeletingRecipe(recipe)}
                      data-testid={`button-delete-recipe-${recipe.id}`}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={!!editingRecipe} onOpenChange={(open) => !open && setEditingRecipe(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Recipe</DialogTitle>
            <DialogDescription>Update the recipe details</DialogDescription>
          </DialogHeader>
          {editingRecipe && (
            <RecipeForm
              defaultValues={editingRecipe}
              onSubmit={(data) => updateMutation.mutate({ id: editingRecipe.id, data })}
              isPending={updateMutation.isPending}
            />
          )}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deletingRecipe} onOpenChange={(open) => !open && setDeletingRecipe(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Recipe</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{deletingRecipe?.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete-recipe">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingRecipe && deleteMutation.mutate(deletingRecipe.id)}
              data-testid="button-confirm-delete-recipe"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function RecipeForm({
  defaultValues,
  onSubmit,
  isPending,
}: {
  defaultValues?: Partial<Recipe>;
  onSubmit: (data: InsertRecipe) => void;
  isPending: boolean;
}) {
  const form = useForm<InsertRecipe>({
    resolver: zodResolver(insertRecipeSchema),
    defaultValues: {
      name: defaultValues?.name || "",
      servings: defaultValues?.servings || 4,
      prepTime: defaultValues?.prepTime || "",
      ingredients: defaultValues?.ingredients || [{ name: "", quantity: "", unit: "" }],
      subRecipes: defaultValues?.subRecipes || [],
      image: defaultValues?.image || "",
    },
  });

  const { fields: ingredientFields, append: appendIngredient, remove: removeIngredient } = useFieldArray({
    control: form.control,
    name: "ingredients",
  });

  const { fields: subRecipeFields, append: appendSubRecipe, remove: removeSubRecipe } = useFieldArray({
    control: form.control,
    name: "subRecipes",
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Recipe Name</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Margherita Pizza" {...field} data-testid="input-recipe-name" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="servings"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Servings</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    {...field}
                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                    data-testid="input-servings"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="prepTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Prep Time (Optional)</FormLabel>
                <FormControl>
                  <Input placeholder="e.g., 30 mins" {...field} data-testid="input-prep-time" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <FormLabel>Ingredients</FormLabel>
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => appendIngredient({ name: "", quantity: "", unit: "" })}
              data-testid="button-add-ingredient"
            >
              <Plus className="h-3 w-3" />
              Add Ingredient
            </Button>
          </div>

          {ingredientFields.map((field, index) => (
            <div key={field.id} className="flex gap-2">
              <FormField
                control={form.control}
                name={`ingredients.${index}.name`}
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormControl>
                      <Input placeholder="Ingredient name" {...field} data-testid={`input-ingredient-name-${index}`} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name={`ingredients.${index}.quantity`}
                render={({ field }) => (
                  <FormItem className="w-24">
                    <FormControl>
                      <Input placeholder="Qty" {...field} data-testid={`input-ingredient-quantity-${index}`} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name={`ingredients.${index}.unit`}
                render={({ field }) => (
                  <FormItem className="w-24">
                    <FormControl>
                      <Input placeholder="Unit" {...field} data-testid={`input-ingredient-unit-${index}`} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => removeIngredient(index)}
                disabled={ingredientFields.length === 1}
                data-testid={`button-remove-ingredient-${index}`}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>

        <Separator />

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <FormLabel>Sub-recipes (Optional)</FormLabel>
              <p className="text-xs text-muted-foreground">e.g., Pizza dough, Sauce</p>
            </div>
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() =>
                appendSubRecipe({
                  id: crypto.randomUUID(),
                  name: "",
                  ingredients: [{ name: "", quantity: "", unit: "" }],
                })
              }
              data-testid="button-add-subrecipe"
            >
              <Plus className="h-3 w-3" />
              Add Sub-recipe
            </Button>
          </div>

          {subRecipeFields.map((field, subIndex) => (
            <Card key={field.id}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between gap-2">
                  <FormField
                    control={form.control}
                    name={`subRecipes.${subIndex}.name`}
                    render={({ field }) => (
                      <FormItem className="flex-1">
                        <FormControl>
                          <Input placeholder="Sub-recipe name" {...field} data-testid={`input-subrecipe-name-${subIndex}`} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => removeSubRecipe(subIndex)}
                    data-testid={`button-remove-subrecipe-${subIndex}`}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                <SubRecipeIngredients subIndex={subIndex} form={form} />
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex gap-2 justify-end pt-4">
          <Button type="submit" disabled={isPending} data-testid="button-submit-recipe">
            {isPending ? "Saving..." : defaultValues?.name ? "Update Recipe" : "Create Recipe"}
          </Button>
        </div>
      </form>
    </Form>
  );
}

function SubRecipeIngredients({ subIndex, form }: { subIndex: number; form: any }) {
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: `subRecipes.${subIndex}.ingredients`,
  });

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-muted-foreground">Ingredients</p>
        <Button
          type="button"
          size="sm"
          variant="ghost"
          onClick={() => append({ name: "", quantity: "", unit: "" })}
          data-testid={`button-add-subrecipe-ingredient-${subIndex}`}
        >
          <Plus className="h-3 w-3" />
          Add
        </Button>
      </div>
      {fields.map((field, ingredientIndex) => (
        <div key={field.id} className="flex gap-2">
          <FormField
            control={form.control}
            name={`subRecipes.${subIndex}.ingredients.${ingredientIndex}.name`}
            render={({ field }) => (
              <FormItem className="flex-1">
                <FormControl>
                  <Input placeholder="Name" {...field} className="text-sm" data-testid={`input-subrecipe-${subIndex}-ingredient-name-${ingredientIndex}`} />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name={`subRecipes.${subIndex}.ingredients.${ingredientIndex}.quantity`}
            render={({ field }) => (
              <FormItem className="w-20">
                <FormControl>
                  <Input placeholder="Qty" {...field} className="text-sm" data-testid={`input-subrecipe-${subIndex}-ingredient-quantity-${ingredientIndex}`} />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name={`subRecipes.${subIndex}.ingredients.${ingredientIndex}.unit`}
            render={({ field }) => (
              <FormItem className="w-20">
                <FormControl>
                  <Input placeholder="Unit" {...field} className="text-sm" data-testid={`input-subrecipe-${subIndex}-ingredient-unit-${ingredientIndex}`} />
                </FormControl>
              </FormItem>
            )}
          />
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => remove(ingredientIndex)}
            disabled={fields.length === 1}
            data-testid={`button-remove-subrecipe-${subIndex}-ingredient-${ingredientIndex}`}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      ))}
    </div>
  );
}
