# Keep it Fresh - Design Guidelines

## Design Approach

**Selected Framework:** Design System Approach inspired by Material Design with elements from consumer productivity apps (Notion, Todoist)

**Rationale:** This is a utility-focused, information-dense application requiring consistent patterns for inventory management, recipe tracking, and meal planning. The design prioritizes efficiency, scannability, and ease of data entry while maintaining an approachable, friendly aesthetic suitable for household use.

## Core Design Elements

### Typography

**Font Families:**
- Primary: Inter (Google Fonts) - Clean, readable for UI elements and data
- Secondary: DM Sans (Google Fonts) - Friendly warmth for headings

**Hierarchy:**
- Page Titles: 32px/2xl, semibold
- Section Headers: 24px/xl, semibold  
- Card Headers: 18px/lg, medium
- Body Text: 16px/base, regular
- Labels/Meta: 14px/sm, medium
- Small Text (dates, counts): 12px/xs, regular

### Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, and 8 consistently
- Component padding: p-4 or p-6
- Section spacing: space-y-6 or space-y-8
- Card gaps: gap-4
- Form field spacing: space-y-4

**Container Strategy:**
- Max width: max-w-7xl for main content
- Sidebar width: w-64 (fixed)
- Content padding: px-6 lg:px-8

### Component Library

#### Navigation
- **Top Bar:** Fixed header with app logo, global search, user profile/household switcher
- **Side Navigation:** Persistent left sidebar with icon + label navigation (Dashboard, Inventory, Recipes, Meal Plan, Shopping List, Settings)
- **Breadcrumbs:** For nested views (Recipe > Sub-recipe)

#### Data Display Components

**Inventory Grid/List:**
- Card-based layout with image placeholder, item name, quantity, expiration date
- Visual indicators: Red badge for expired, orange for expiring soon (3 days), green for fresh
- Quick actions: Edit, Delete icons on hover
- Grid view (default): 3-4 columns on desktop, 2 on tablet, 1 on mobile
- List view (alternative): Table format with sortable columns

**Recipe Cards:**
- Thumbnail image (placeholder if none)
- Recipe title, serving size, prep time
- Ingredient count indicator
- "Can Make" badge if all ingredients in stock

**Calendar View (Meal Plan):**
- Weekly grid layout with day columns
- Meal cards within each day (breakfast, lunch, dinner slots)
- Drag-and-drop zones for meal assignment
- "+" button to add meals to specific dates

#### Form Components

**Input Fields:**
- Standard text inputs with floating labels
- Number spinners for quantities
- Date pickers for expiration dates
- Dropdowns for categories (Fridge, Pantry, Shelf assignments)
- Multi-select for recipe ingredients

**Buttons:**
- Primary: Solid with medium weight text
- Secondary: Outlined
- Tertiary: Text only
- Icon buttons: Consistent 40px touch targets
- When placed over images: Semi-transparent background with backdrop blur (bg-white/20 backdrop-blur-md)

**User Profile Management:**
- User cards with avatar, name, assigned shelf/area
- Add/Remove user actions
- Household switcher dropdown in header

#### Overlays & Modals

**Modal Dialogs:**
- Centered, max-w-2xl
- Overlay background: bg-black/50
- Padding: p-6
- Close button: Top right corner

**Slide-out Panels:**
- For recipe details, food item editing
- Slides from right, w-96 or w-1/3
- Overlay backdrop

**Toast Notifications:**
- Bottom-right positioning
- Auto-dismiss after 3 seconds
- Success (green accent), Warning (orange), Error (red)

### Special Features

**Stock Checker:**
- Side-by-side comparison layout
- Left column: Recipe requirements
- Right column: Current inventory with match indicators
- Missing items highlighted with "Add to Shopping List" action

**Shopping List:**
- Checkable list items
- Group by category (Produce, Dairy, Pantry)
- Swipe to delete on mobile
- "Add all to cart" bulk action

**Expiration Dashboard:**
- Priority list sorted by expiration date
- Visual timeline showing items expiring this week
- Quick action buttons: Use in Recipe, Mark as Used, Extend Date

### Animations

Use sparingly:
- Subtle fade-in for cards on load (150ms)
- Smooth transitions for modal/panel appearance (200ms)
- Checkbox/toggle state changes (100ms)
- No scroll animations or complex interactions

### Images

**Hero Section:** None - This is a utility app that should open directly to the dashboard

**Food/Recipe Images:**
- Inventory items: Square thumbnails (80x80px) with rounded corners (rounded-lg)
- Recipe cards: 16:9 aspect ratio headers (w-full)
- Placeholders: Light gradient backgrounds with food icons (from Heroicons - cake, shopping-bag, etc.)
- User avatars: Circular, 40px default size

**Icon Library:** Heroicons (outline style for navigation, solid for actions)

### Accessibility
- Consistent focus states with visible outlines
- Color indicators paired with icons/text labels
- Proper ARIA labels for all interactive elements
- Keyboard navigation support for all features
- Form validation with clear error messages