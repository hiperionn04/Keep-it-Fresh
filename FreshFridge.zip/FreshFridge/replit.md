# Keep it Fresh - Food Inventory & Meal Planning Application

## Overview

Keep it Fresh is a food inventory and meal planning web application designed to help users track their groceries, manage expiration dates, plan meals, create recipes, and generate shopping lists. The application aims to reduce food waste by providing visual indicators for expiring items and facilitating efficient meal planning based on available inventory.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework:** React with TypeScript using Vite as the build tool

**UI Component Library:** shadcn/ui (Radix UI primitives) with Tailwind CSS for styling

**Design System:**
- Material Design-inspired approach with elements from consumer productivity apps
- Typography: Inter (primary) and DM Sans (secondary) fonts from Google Fonts
- Spacing primitives: Tailwind units (2, 4, 6, 8)
- Color scheme: Neutral base with customizable theme variables supporting light/dark modes
- Component patterns: Card-based layouts with consistent spacing and border treatments

**Routing:** wouter for client-side routing

**State Management:**
- TanStack Query (React Query) for server state management and caching
- React Context API for:
  - User selection and persistence (UserContext)
  - Theme management (ThemeProvider)

**Key Frontend Patterns:**
- Form handling: React Hook Form with Zod validation
- Type safety: Full TypeScript coverage with shared schemas
- Responsive design: Mobile-first approach with Tailwind breakpoints

### Backend Architecture

**Server Framework:** Express.js running on Node.js

**API Design:** RESTful API with resource-based endpoints:
- `/api/users` - User management
- `/api/food-items` - Inventory tracking
- `/api/recipes` - Recipe management with ingredients and sub-recipes
- `/api/meal-plans` - Meal calendar planning
- `/api/shopping-list` - Shopping list items

**Data Layer:**
- Drizzle ORM for type-safe database queries
- Schema-first approach with Zod validation using drizzle-zod
- In-memory storage implementation (interface-based for future persistence)

**Development Setup:**
- Development: tsx for TypeScript execution without compilation
- Production: esbuild for server bundling, Vite for client bundling
- HMR support via Vite middleware in development

### Data Storage Solutions

**Database:** PostgreSQL (configured via Drizzle)
- Connection: Neon Database serverless driver
- Migrations: Managed through drizzle-kit
- Schema location: `shared/schema.ts` for type sharing between client/server

**Data Models:**
- **Users:** Profile information with optional avatar and assigned shelf
- **Food Items:** Name, quantity, unit, expiration date, storage location, category, user association
- **Recipes:** Name, servings, prep time, ingredients (JSONB), optional sub-recipes (JSONB), image
- **Meal Plans:** Recipe association with date and meal type
- **Shopping List Items:** Name, quantity, category, checked status

**Current Implementation:** In-memory storage with IStorage interface, designed for easy swapping to persistent database implementation

### Authentication and Authorization

**Current State:** No authentication system implemented

**User Management:**
- Multi-user support with user switching capability
- User ID stored in localStorage for session persistence
- No password or session management
- Food items filtered by user ID on client side

**Future Considerations:** Interface-based storage allows for adding authentication layer without architectural changes

### External Dependencies

**UI Components:**
- Radix UI primitives (accordion, dialog, dropdown, popover, etc.)
- cmdk for command palette functionality
- embla-carousel-react for carousel components
- lucide-react for icon system

**Date Handling:**
- date-fns for date manipulation and formatting
- Used for expiration tracking and meal plan calendar

**Validation:**
- Zod for runtime type validation
- @hookform/resolvers for form validation integration

**Database:**
- @neondatabase/serverless for PostgreSQL connection
- drizzle-orm and drizzle-kit for ORM and migrations

**Development Tools:**
- @replit/vite-plugin-runtime-error-modal for error handling
- @replit/vite-plugin-cartographer and dev-banner for Replit integration

**Styling:**
- Tailwind CSS with PostCSS
- class-variance-authority for component variant management
- tailwind-merge and clsx for className utilities