import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, date, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  avatar: text("avatar"),
  assignedShelf: text("assigned_shelf"),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const foodItems = pgTable("food_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  quantity: text("quantity").notNull(),
  unit: text("unit").notNull(),
  expirationDate: date("expiration_date").notNull(),
  storageLocation: text("storage_location").notNull(),
  category: text("category"),
});

export const insertFoodItemSchema = createInsertSchema(foodItems).omit({ id: true });
export type InsertFoodItem = z.infer<typeof insertFoodItemSchema>;
export type FoodItem = typeof foodItems.$inferSelect;

export const recipes = pgTable("recipes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  servings: integer("servings").notNull(),
  prepTime: text("prep_time"),
  ingredients: jsonb("ingredients").notNull().$type<RecipeIngredient[]>(),
  subRecipes: jsonb("sub_recipes").$type<SubRecipe[]>(),
  image: text("image"),
});

export type RecipeIngredient = {
  name: string;
  quantity: string;
  unit: string;
};

export type SubRecipe = {
  id: string;
  name: string;
  ingredients: RecipeIngredient[];
};

export const insertRecipeSchema = createInsertSchema(recipes).omit({ id: true }).extend({
  ingredients: z.array(z.object({
    name: z.string(),
    quantity: z.string(),
    unit: z.string(),
  })),
  subRecipes: z.array(z.object({
    id: z.string(),
    name: z.string(),
    ingredients: z.array(z.object({
      name: z.string(),
      quantity: z.string(),
      unit: z.string(),
    })),
  })).optional(),
});

export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type Recipe = typeof recipes.$inferSelect;

export const mealPlans = pgTable("meal_plans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: date("date").notNull(),
  mealType: text("meal_type").notNull(),
  recipeId: varchar("recipe_id").notNull(),
  recipeName: text("recipe_name").notNull(),
  servings: integer("servings"),
});

export const insertMealPlanSchema = createInsertSchema(mealPlans).omit({ id: true });
export type InsertMealPlan = z.infer<typeof insertMealPlanSchema>;
export type MealPlan = typeof mealPlans.$inferSelect;

export const shoppingListItems = pgTable("shopping_list_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  quantity: text("quantity").notNull(),
  unit: text("unit").notNull(),
  category: text("category").notNull(),
  checked: boolean("checked").notNull().default(false),
});

export const insertShoppingListItemSchema = createInsertSchema(shoppingListItems).omit({ id: true });
export type InsertShoppingListItem = z.infer<typeof insertShoppingListItemSchema>;
export type ShoppingListItem = typeof shoppingListItems.$inferSelect;
