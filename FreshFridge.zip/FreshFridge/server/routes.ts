import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertUserSchema,
  insertFoodItemSchema,
  insertRecipeSchema,
  insertMealPlanSchema,
  insertShoppingListItemSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Users
  app.get("/api/users", async (req, res) => {
    const users = await storage.getUsers();
    res.json(users);
  });

  app.get("/api/users/:id", async (req, res) => {
    const user = await storage.getUser(req.params.id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json(user);
  });

  app.post("/api/users", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      const user = await storage.createUser(data);
      res.status(201).json(user);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    const user = await storage.updateUser(req.params.id, req.body);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json(user);
  });

  app.delete("/api/users/:id", async (req, res) => {
    const deleted = await storage.deleteUser(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "User not found" });
    }
    res.status(204).send();
  });

  // Food Items
  app.get("/api/food-items", async (req, res) => {
    const items = await storage.getFoodItems();
    res.json(items);
  });

  app.get("/api/food-items/:id", async (req, res) => {
    const item = await storage.getFoodItem(req.params.id);
    if (!item) {
      return res.status(404).json({ message: "Food item not found" });
    }
    res.json(item);
  });

  app.post("/api/food-items", async (req, res) => {
    try {
      const data = insertFoodItemSchema.parse(req.body);
      const item = await storage.createFoodItem(data);
      res.status(201).json(item);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/food-items/:id", async (req, res) => {
    const item = await storage.updateFoodItem(req.params.id, req.body);
    if (!item) {
      return res.status(404).json({ message: "Food item not found" });
    }
    res.json(item);
  });

  app.delete("/api/food-items/:id", async (req, res) => {
    const deleted = await storage.deleteFoodItem(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "Food item not found" });
    }
    res.status(204).send();
  });

  // Recipes
  app.get("/api/recipes", async (req, res) => {
    const recipes = await storage.getRecipes();
    res.json(recipes);
  });

  app.get("/api/recipes/:id", async (req, res) => {
    const recipe = await storage.getRecipe(req.params.id);
    if (!recipe) {
      return res.status(404).json({ message: "Recipe not found" });
    }
    res.json(recipe);
  });

  app.post("/api/recipes", async (req, res) => {
    try {
      const data = insertRecipeSchema.parse(req.body);
      const recipe = await storage.createRecipe(data);
      res.status(201).json(recipe);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/recipes/:id", async (req, res) => {
    try {
      const data = insertRecipeSchema.parse(req.body);
      const recipe = await storage.updateRecipe(req.params.id, data);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      res.json(recipe);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/recipes/:id", async (req, res) => {
    const deleted = await storage.deleteRecipe(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "Recipe not found" });
    }
    res.status(204).send();
  });

  // Meal Plans
  app.get("/api/meal-plans", async (req, res) => {
    const plans = await storage.getMealPlans();
    res.json(plans);
  });

  app.get("/api/meal-plans/:id", async (req, res) => {
    const plan = await storage.getMealPlan(req.params.id);
    if (!plan) {
      return res.status(404).json({ message: "Meal plan not found" });
    }
    res.json(plan);
  });

  app.post("/api/meal-plans", async (req, res) => {
    try {
      const data = insertMealPlanSchema.parse(req.body);
      const plan = await storage.createMealPlan(data);
      res.status(201).json(plan);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/meal-plans/:id", async (req, res) => {
    const deleted = await storage.deleteMealPlan(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "Meal plan not found" });
    }
    res.status(204).send();
  });

  // Shopping List
  app.get("/api/shopping-list", async (req, res) => {
    const items = await storage.getShoppingListItems();
    res.json(items);
  });

  app.get("/api/shopping-list/:id", async (req, res) => {
    const item = await storage.getShoppingListItem(req.params.id);
    if (!item) {
      return res.status(404).json({ message: "Shopping list item not found" });
    }
    res.json(item);
  });

  app.post("/api/shopping-list", async (req, res) => {
    try {
      const data = insertShoppingListItemSchema.parse(req.body);
      const item = await storage.createShoppingListItem(data);
      res.status(201).json(item);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/shopping-list/:id", async (req, res) => {
    const item = await storage.updateShoppingListItem(req.params.id, req.body);
    if (!item) {
      return res.status(404).json({ message: "Shopping list item not found" });
    }
    res.json(item);
  });

  app.delete("/api/shopping-list/:id", async (req, res) => {
    const deleted = await storage.deleteShoppingListItem(req.params.id);
    if (!deleted) {
      return res.status(404).json({ message: "Shopping list item not found" });
    }
    res.status(204).send();
  });

  app.delete("/api/shopping-list/checked", async (req, res) => {
    await storage.deleteCheckedShoppingListItems();
    res.status(204).send();
  });

  const httpServer = createServer(app);
  return httpServer;
}
