import {
  type User,
  type InsertUser,
  type FoodItem,
  type InsertFoodItem,
  type Recipe,
  type InsertRecipe,
  type MealPlan,
  type InsertMealPlan,
  type ShoppingListItem,
  type InsertShoppingListItem,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUsers(): Promise<User[]>;
  getUser(id: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<User>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;

  // Food Items
  getFoodItems(): Promise<FoodItem[]>;
  getFoodItem(id: string): Promise<FoodItem | undefined>;
  createFoodItem(item: InsertFoodItem): Promise<FoodItem>;
  updateFoodItem(id: string, data: Partial<FoodItem>): Promise<FoodItem | undefined>;
  deleteFoodItem(id: string): Promise<boolean>;
  deleteFoodItemsByUserId(userId: string): Promise<void>;

  // Recipes
  getRecipes(): Promise<Recipe[]>;
  getRecipe(id: string): Promise<Recipe | undefined>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  updateRecipe(id: string, data: InsertRecipe): Promise<Recipe | undefined>;
  deleteRecipe(id: string): Promise<boolean>;

  // Meal Plans
  getMealPlans(): Promise<MealPlan[]>;
  getMealPlan(id: string): Promise<MealPlan | undefined>;
  createMealPlan(plan: InsertMealPlan): Promise<MealPlan>;
  deleteMealPlan(id: string): Promise<boolean>;

  // Shopping List
  getShoppingListItems(): Promise<ShoppingListItem[]>;
  getShoppingListItem(id: string): Promise<ShoppingListItem | undefined>;
  createShoppingListItem(item: InsertShoppingListItem): Promise<ShoppingListItem>;
  updateShoppingListItem(id: string, data: Partial<ShoppingListItem>): Promise<ShoppingListItem | undefined>;
  deleteShoppingListItem(id: string): Promise<boolean>;
  deleteCheckedShoppingListItems(): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private foodItems: Map<string, FoodItem>;
  private recipes: Map<string, Recipe>;
  private mealPlans: Map<string, MealPlan>;
  private shoppingListItems: Map<string, ShoppingListItem>;

  constructor() {
    this.users = new Map();
    this.foodItems = new Map();
    this.recipes = new Map();
    this.mealPlans = new Map();
    this.shoppingListItems = new Map();

    // Initialize with a default user
    const defaultUser: User = {
      id: randomUUID(),
      name: "Default User",
      avatar: null,
      assignedShelf: null,
    };
    this.users.set(defaultUser.id, defaultUser);
  }

  // Users
  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, data: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updated = { ...user, ...data };
    this.users.set(id, updated);
    return updated;
  }

  async deleteUser(id: string): Promise<boolean> {
    await this.deleteFoodItemsByUserId(id);
    return this.users.delete(id);
  }

  // Food Items
  async getFoodItems(): Promise<FoodItem[]> {
    return Array.from(this.foodItems.values());
  }

  async getFoodItem(id: string): Promise<FoodItem | undefined> {
    return this.foodItems.get(id);
  }

  async createFoodItem(insertItem: InsertFoodItem): Promise<FoodItem> {
    const id = randomUUID();
    const item: FoodItem = { ...insertItem, id };
    this.foodItems.set(id, item);
    return item;
  }

  async updateFoodItem(id: string, data: Partial<FoodItem>): Promise<FoodItem | undefined> {
    const item = this.foodItems.get(id);
    if (!item) return undefined;
    const updated = { ...item, ...data };
    this.foodItems.set(id, updated);
    return updated;
  }

  async deleteFoodItem(id: string): Promise<boolean> {
    return this.foodItems.delete(id);
  }

  async deleteFoodItemsByUserId(userId: string): Promise<void> {
    const itemsToDelete = Array.from(this.foodItems.values())
      .filter((item) => item.userId === userId)
      .map((item) => item.id);
    itemsToDelete.forEach((id) => this.foodItems.delete(id));
  }

  // Recipes
  async getRecipes(): Promise<Recipe[]> {
    return Array.from(this.recipes.values());
  }

  async getRecipe(id: string): Promise<Recipe | undefined> {
    return this.recipes.get(id);
  }

  async createRecipe(insertRecipe: InsertRecipe): Promise<Recipe> {
    const id = randomUUID();
    const recipe: Recipe = { ...insertRecipe, id };
    this.recipes.set(id, recipe);
    return recipe;
  }

  async updateRecipe(id: string, data: InsertRecipe): Promise<Recipe | undefined> {
    const recipe = this.recipes.get(id);
    if (!recipe) return undefined;
    const updated: Recipe = { ...recipe, ...data };
    this.recipes.set(id, updated);
    return updated;
  }

  async deleteRecipe(id: string): Promise<boolean> {
    return this.recipes.delete(id);
  }

  // Meal Plans
  async getMealPlans(): Promise<MealPlan[]> {
    return Array.from(this.mealPlans.values());
  }

  async getMealPlan(id: string): Promise<MealPlan | undefined> {
    return this.mealPlans.get(id);
  }

  async createMealPlan(insertPlan: InsertMealPlan): Promise<MealPlan> {
    const id = randomUUID();
    const plan: MealPlan = { ...insertPlan, id };
    this.mealPlans.set(id, plan);
    return plan;
  }

  async deleteMealPlan(id: string): Promise<boolean> {
    return this.mealPlans.delete(id);
  }

  // Shopping List
  async getShoppingListItems(): Promise<ShoppingListItem[]> {
    return Array.from(this.shoppingListItems.values());
  }

  async getShoppingListItem(id: string): Promise<ShoppingListItem | undefined> {
    return this.shoppingListItems.get(id);
  }

  async createShoppingListItem(insertItem: InsertShoppingListItem): Promise<ShoppingListItem> {
    const id = randomUUID();
    const item: ShoppingListItem = { ...insertItem, id };
    this.shoppingListItems.set(id, item);
    return item;
  }

  async updateShoppingListItem(
    id: string,
    data: Partial<ShoppingListItem>
  ): Promise<ShoppingListItem | undefined> {
    const item = this.shoppingListItems.get(id);
    if (!item) return undefined;
    const updated = { ...item, ...data };
    this.shoppingListItems.set(id, updated);
    return updated;
  }

  async deleteShoppingListItem(id: string): Promise<boolean> {
    return this.shoppingListItems.delete(id);
  }

  async deleteCheckedShoppingListItems(): Promise<void> {
    const checkedItems = Array.from(this.shoppingListItems.values())
      .filter((item) => item.checked)
      .map((item) => item.id);
    checkedItems.forEach((id) => this.shoppingListItems.delete(id));
  }
}

export const storage = new MemStorage();
